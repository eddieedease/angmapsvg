'use strict';

/**
 * @ngdoc service
 * @name lsamapApp.ipa
 * @description
 * # ipa
 * Service in the lsamapApp.
 */
angular.module('lsamapApp')
  .service('ipa', function () {
    // AngularJS will instantiate a singleton by calling "new" on this function
  });
