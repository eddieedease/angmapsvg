'use strict';

/**
 * @ngdoc function
 * @name lsamapApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the lsamapApp
 */
angular.module('lsamapApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
