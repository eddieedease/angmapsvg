'use strict';

/**
 * @ngdoc function
 * @name lsamapApp.controller:AdminlsaCtrl
 * @description
 * # AdminlsaCtrl
 * Controller of the lsamapApp
 */
angular.module('lsamapApp')
  .controller('AdminlsaCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
