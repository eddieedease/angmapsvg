# Ng SVG Directive experimenting

Trying to make an interactive svg map of the municipalities from the Netherlands
svg is slighly altered from the WikiCommons one, to set it up just right.

#Install
install with 'npm install && bower install'

#Serve & Build
Run `grunt` for building and `grunt serve` for preview.

IMPORTANT
CORS are set up on server files, for testing purposes. If production --> disable for safety
