<?php
$db_name = 'lsamap';
$hostname = 'localhost';
$username = 'root';
$password = 'root';
?>
